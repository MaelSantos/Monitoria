package model;

public class BackupException extends Exception {

	public BackupException(String mensagem) {
		super(mensagem);
	}
	
}
