package model;

public interface Dvd {

	public String getInformacao(Dvd dvd);
	
}
