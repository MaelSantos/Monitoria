package model;

public class CaracterException extends Exception {

	public CaracterException(String mensagem) {
		super(mensagem);
	}
	
}
