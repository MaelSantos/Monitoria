package model;

public interface Livro {

	public String getInformacao(Livro livro);
}
